function P = Parameters_RRR(q0,v0,a0,qf,vf,af)
P = [q0;v0;a0;qf;vf;af];
end