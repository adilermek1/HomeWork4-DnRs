function T2 = T2_RRR(q,L)
T2 = Rz(q(1))*Tz(L(1))*Rx(q(2));
end