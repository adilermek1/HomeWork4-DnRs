function T3 = T3_RRR(q,L)
T3 = Rz(q(1))*Tz(L(1))*Rx(q(2))*Tz(L(2))*Rx(q(3));
end