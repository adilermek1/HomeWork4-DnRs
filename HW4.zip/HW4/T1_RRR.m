function T1 = T1_RRR(q)
T1 = Rz(q(1));
end

